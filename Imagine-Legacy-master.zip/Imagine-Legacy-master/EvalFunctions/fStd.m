function [dDataOut, sName, sUnitFormat] = fStd(dData)

sName = 'Std';
sUnitFormat = '';
dDataOut = std(dData);
% =========================================================================
% *** END OF FUNCTION fEvalROIMean
% =========================================================================